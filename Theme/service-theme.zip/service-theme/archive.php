<?php get_header(); ?>

<div class="sr-page-wrapper">
    <div class="container py-5">

        <header class="mb-4">
            <h1 class="mb-3">
                <?php the_archive_title(); ?>
            </h1>
            <?php the_archive_description('<p class="text-muted">', '</p>'); ?>
        </header>

        <div class="row g-4">

            <?php if ( have_posts() ) : ?>
                <?php while ( have_posts() ) : the_post(); ?>

                    <div class="col-md-4">
                        <article <?php post_class('sr-archive-card h-100 p-4 border rounded'); ?>>
                            
                            <h4>
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_title(); ?>
                                </a>
                            </h4>

                            <p class="small text-muted mb-2">
                                <?php echo get_the_date(); ?>
                            </p>

                            <div class="sr-excerpt">
                                <?php the_excerpt(); ?>
                            </div>

                            <a class="btn btn-sm btn-outline-primary mt-2" href="<?php the_permalink(); ?>">
                                View Details
                            </a>

                        </article>
                    </div>

                <?php endwhile; ?>
            <?php else : ?>
                <p>No posts found.</p>
            <?php endif; ?>

        </div>

        <!-- Pagination -->
        <div class="mt-5">
            <?php the_posts_pagination(); ?>
        </div>

    </div>
</div>

<?php get_footer(); ?>
