jQuery(function ($) {

    
    jQuery(document).on('click', '.contact  .submit-btn', function (e) {
        e.preventDefault();
        
        const $btn  = jQuery(this);
        const $form = $btn.closest('.sr-lead-form');
        const formId = $form.data('form-id');

        // Scoped response box
        const $response = jQuery('.response-message[data-form-id="' + formId + '"]');

        // Clear previous errors (scoped)
        $form.find('.error').text('');
        $response.text('').removeClass('text-success text-danger');

        
        // Read values (scoped)
        const name    = $.trim($form.find('.name').val());
        const email   = $.trim($form.find('.email').val());
        const phone   = $.trim($form.find('.phone').val());
        const service = $form.find('.service').val();

        
        let hasError = false;
        
        // Frontemd Validation
        if (!name) {
            $form.find('.name-error').show();
            $form.find('.name-error').text('Name is required');
            hasError = true;
        }

        if (!email) {
            $form.find('.email-error').show();
            $form.find('.email-error').text('Email is required');
            hasError = true;
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            $form.find('.email-error').show();
            $form.find('.email-error').text('Enter a valid email');
            hasError = true;
        }

        if (!phone) {
            $form.find('.phone-error').show();
            $form.find('.phone-error').text('Phone is required');
            hasError = true;
        }

        if (!service) {
            $form.find('.service-error').show();
            $form.find('.service-error').text('Please select a service');
            hasError = true;
        }

        // Stop here if validation failed
        if (hasError) {
            return;
        }

        jQuery.post(srLeadForm.ajaxurl, {
            action: 'sr_submit_lead_form',
            nonce: srLeadForm.nonce,
            name: name,
            email: email,
            phone: phone,
            service: service
        }, function (response) {
            if (response.success) {
                $response.show();
                $response.addClass('text-success').text(response.data.message);
                $form[0].reset();
            } else {
                $response.show();
                $response.addClass('text-danger').text('Something went wrong.');
            }
        });

    });

});

