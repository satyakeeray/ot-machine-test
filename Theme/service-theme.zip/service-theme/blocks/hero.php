<!-- Hero -->

<?php
// ACF Fields
$hero_title     = get_field('sr_hero_title') ?: __( 'Grow Your Business with Smart Services', 'service-theme'  );
$hero_subtitle  = get_field('sr_hero_subtitle') ?: __( 'High quality digital solutions to help you scale faster with modern technology and proven strategies.' , 'service-theme'  );
$hero_cta       = get_field('sr_hero_cta_button') ?: [];
$block_id       = wp_generate_uuid4();

?>

<section class="sr-hero sr-hero-<?php echo $block_id ?>" id="sr-hero-<?php echo $block_id ?>">
    <div class="container">

        <?php if ($hero_title) : ?>
            <h1><?php echo esc_html($hero_title); ?></h1>
        <?php endif; ?>

        <?php if ($hero_subtitle) : ?>
            <p><?php echo esc_html($hero_subtitle); ?></p>
        <?php endif; ?>

        <?php if (!empty($hero_cta)) : ?>
            <a 
                href="<?php echo esc_url($hero_cta['url']); ?>" 
                target="<?php echo esc_attr($hero_cta['target'] ?: '_self'); ?>" 
                class="btn btn-primary btn-lg"
            >
                <?php echo esc_html($hero_cta['title']); ?>
            </a>
        <?php endif; ?>

    </div>
</section>
