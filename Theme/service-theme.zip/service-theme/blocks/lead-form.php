 <!-- Lead Form -->
<?php 
$sr_form_title      = get_field('sr_form_title') ?: '';
$sr_form_shortcode  = get_field('sr_form_shortcode') ?: "[sr_lead_form]";
$block_id           = wp_generate_uuid4();
if( !empty( $sr_form_title ) || !empty( $sr_form_shortcode ) ): 
?>
    <section id="contact" class="py-5 sr-form-section contact contact-<?php echo $block_id; ?>">
        <div class="container">
            <h2 class="text-center mb-4"><?php echo $sr_form_title; ?></h2>
            <?php echo do_shortcode( $sr_form_shortcode ); ?>
        </div>
    </section>
<?php endif; ?>