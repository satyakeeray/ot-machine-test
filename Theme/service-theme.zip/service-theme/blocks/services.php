<!-- Services -->

<?php
$services_title     = get_field('sr_services_title') ?: '';
$chosen_services    = get_field('sr_choose_service') ?: [];
$show_all_btn       = get_field('sr_services_show_all_btn') ?: false;
$services_all_url   = get_field('sr_services_all_url') ?: [];
$block_id           = wp_generate_uuid4();

// Fallback: CPT archive URL (change CPT slug if needed)
$default_archive_url = get_post_type_archive_link('service');
$all_services_url    = !empty($services_all_url) ? $services_all_url['url'] : $default_archive_url;
?>

<?php if ($services_title || !empty($chosen_services) || $show_all_btn) : ?>
    <section id="services-<?php echo $block_id; ?>" class="py-5 services services-<?php echo $block_id; ?>">
        <div class="container">

            <?php if (!empty($services_title)) : ?>
                <h2 class="text-center mb-5">
                    <?php echo esc_html($services_title); ?>
                </h2>
            <?php endif; ?>

            <?php if (!empty($chosen_services) && is_array($chosen_services)) : ?>
                <div class="row g-4">

                    <?php foreach ($chosen_services as $service_id) : 
                        $title                      = get_the_title($service_id);
                        $post_status                = get_post_status( $service_id );
                        $sr_cpt_short_description   = get_field( 'sr_cpt_short_description' , $service_id  ) ?: '';
                        $sr_cpt_icon                = get_field( 'sr_cpt_icon' , $service_id  ) ?: '';
                        $sr_cpt_features_list       = get_field( 'sr_cpt_features_list' , $service_id  ) ?: [];
                        $sr_cpt_price               = get_field( 'sr_cpt_price' , $service_id  ) ?: 0;
                        $sr_cpt_status              = get_field( 'sr_cpt_status' , $service_id  ) ?: 'active';
                        $price                      = number_format( $sr_cpt_price, 2 );
                        $thumb_id                   = get_post_thumbnail_id($service_id);
                        $thumb_url                  = $thumb_id ? wp_get_attachment_image_url($thumb_id, 'large') : get_template_directory_uri() . '/assets/images/no-image.webp';
                    ?>

                        <?php if ( ( $post_status == 'publish' && $sr_cpt_status == 'active' ) && ( $title || $desc || $thumb_url || $price ) ) : ?>
                            <div class="col-lg-4 col-md-6">
                                <div class="sr-service-card">

                                    <?php if (!empty($thumb_url)) : ?>
                                        <div class="sr-service-thumb">
                                            <img 
                                                src="<?php echo esc_url($thumb_url); ?>" 
                                                alt="<?php echo esc_attr($title); ?>" 
                                                loading="lazy"
                                            />
                                        </div>
                                    <?php endif; ?>

                                    <?php if (!empty($title)) : ?>
                                        <h4><?php echo esc_html($title); ?></h4>
                                    <?php endif; ?>

                                    <?php if (!empty($sr_cpt_short_description)) : ?>
                                        <p><?php echo esc_html($sr_cpt_short_description); ?></p>
                                    <?php endif; ?>

                                    <?php if (!empty($sr_cpt_features_list)) : ?>
                                        <ul class="list-unstyled small text-muted">
                                            <?php foreach( $sr_cpt_features_list as $feature ): ?>
                                                <li>✔ <?php echo $feature['sr_cpt_feature']; ?></li>
                                            <?php endforeach; ?>
                                        </ul>
                                    <?php endif; ?>

                                    <?php if (!empty($price)) : ?>
                                        <div class="sr-price">
                                            $<?php echo esc_html($price); ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if( !empty( $sr_cpt_icon  ) ): ?>
                                    <div class="sr-icon mt-2 mb-2">
                                        <img decoding="async" src="<?php echo $sr_cpt_icon;?>" alt="" srcset="">
                                    </div>
                                    <?php endif; ?>

                                </div>
                            </div>
                        <?php endif; ?>

                    <?php endforeach; ?>

                </div>
            <?php endif; ?>

            <?php if ( $show_all_btn ) : ?>
                <div class="text-center mt-4">
                    <a 
                        href="<?php echo esc_url($all_services_url); ?>" 
                        class="btn btn-primary btn-lg"
                    >
                        <?php
                        if( !empty( $services_all_url ) ) {
                            echo $services_all_url['title'];
                        } else {
                            echo __( 'View All Services' , 'service-theme' );
                        }
                        ?>
                    </a>
                </div>
            <?php endif; ?>

        </div>
    </section>
<?php endif; ?>
