 <!-- Why Choose -->

<?php
$why_title = get_field('sr_why_title') ?: '';
$why_items = get_field('sr_why_items') ?: [];
$block_id  = wp_generate_uuid4();
?>

<?php if ($why_title || !empty($why_items)) : ?>
<section id="why-<?php echo $block_id; ?>" class="py-5 bg-light why">
    <div class="container">

        <?php if (!empty($why_title)) : ?>
            <h2 class="text-center mb-5">
                <?php echo esc_html($why_title); ?>
            </h2>
        <?php endif; ?>

        <?php if (!empty($why_items)) : ?>
            <div class="row g-4">

                <?php foreach ($why_items as $item) : 
                    $icon  = !empty($item['sr_why_icon']) ? $item['sr_why_icon'] : '';
                    $title = !empty($item['sr_why_item_title']) ? $item['sr_why_item_title'] : '';
                    $desc  = !empty($item['sr_why_item_text']) ? $item['sr_why_item_text'] : '';
                ?>

                    <?php if ($title || $desc || $icon) : ?>
                        <div class="col-md-4">
                            <div class="sr-why-card">

                                <?php if (!empty($icon)) : ?>
                                    <div class="sr-icon mb-2">
                                        <img src="<?php echo $icon;  ?>" alt="" srcset="">
                                    </div>
                                <?php endif; ?>

                                <?php if (!empty($title)) : ?>
                                    <h5><?php echo esc_html($title); ?></h5>
                                <?php endif; ?>

                                <?php if (!empty($desc)) : ?>
                                    <p><?php echo esc_html($desc); ?></p>
                                <?php endif; ?>

                            </div>
                        </div>
                    <?php endif; ?>

                <?php endforeach; ?>

            </div>
        <?php endif; ?>

    </div>
</section>
<?php endif; ?>
