<!-- Footer -->
        <footer class="sr-footer">
            <div class="container">
                <p>
                    <?php 
                    $rights_text = esc_html__('All rights reserved.', 'service-theme');
                    echo sprintf(
                        esc_html__('© %d %s. %s', 'service-theme'),
                        date('Y'),
                        get_bloginfo('name'),
                        $rights_text
                    );
                    ?>
                </p>
                <!-- <p><a href="#">Privacy Policy</a> · <a href="#">Terms</a></p> -->
            </div>
        </footer>
        <?php wp_footer(); ?>
    </body>
</html>