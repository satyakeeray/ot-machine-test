<?php

function sr_allow_svg_uploads( $mimes ) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter( 'upload_mimes', 'sr_allow_svg_uploads' );

require_once get_template_directory() . '/includes/theme-setup.php'; // Activity after theme setup
require_once get_template_directory() . '/includes/enqueue.php';  // Enqueueing scripts and style for frontend.
require_once get_template_directory() . '/includes/acf-blocks.php';  // Registering acf blocks
require_once get_template_directory() . '/includes/cpt.php'; // Registering CPT
require_once get_template_directory() . '/includes/shortcode.php'; // Registering shortcode form lead form
require_once get_template_directory() . '/includes/ajax.php'; // Handles ajax request from lead form
require_once get_template_directory() . '/includes/common.php'; // Some common functions
require_once get_template_directory() . '/includes/admin-functionalities.php'; // Admin page related source code.


