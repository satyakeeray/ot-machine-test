<!doctype html>
<html <?php language_attributes(); ?>>
    <head>
       <meta charset="<?php bloginfo( 'charset' ); ?>">
        <title><?php bloginfo( 'name' ); ?></title>
        <!-- Basic -->
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Site Metas -->
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <?php wp_head(); ?>
    </head>
    <body <?php body_class(); ?>>
        <!-- Header -->
        <header class="sr-header">
            <nav class="navbar navbar-expand-lg">
                <div class="container">
                    <a class="navbar-brand" href="<?php get_site_url(); ?>"><?php bloginfo( 'name' ); ?></a>
                    <button class="navbar-toggler text-white" data-bs-toggle="collapse" data-bs-target="#srNav">
                        ☰
                    </button>
                    <div class="collapse navbar-collapse" id="srNav">
                        <!-- <ul class="navbar-nav ms-auto">
                            <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
                            <li class="nav-item"><a class="nav-link" href="#why">Why Us</a></li>
                            <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
                        </ul> -->
                    </div>
                </div>
            </nav>
        </header>