<?php
// Registering blocks

add_action('acf/init', function () {

    if ( ! function_exists('acf_register_block_type') ) {
        return;
    }

    // Block names
    $blocks = array(
        'hero'       => 'Hero Section',
        'services'   => 'Services Grid',
        'why-choose' => 'Why Choose Us',
        'lead-form'  => 'Lead Form',
    );

    // Registering blocks with templates
    foreach ($blocks as $slug => $title) {
        acf_register_block_type(array(
            'name'            => 'sr-' . $slug,
            'title'           => __('SR ' . $title),
            'render_template' => get_template_directory() . '/blocks/' . $slug . '.php',
            'category'        => 'layout',
            'icon'            => 'layout',
            'mode'            => 'edit',
        ));
    }
});