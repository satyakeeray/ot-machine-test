<?php
add_action('admin_menu', 'sr_register_leads_menu');

function sr_register_leads_menu() {
    add_menu_page(
        'Leads',
        'Leads',
        'manage_options',
        'sr-leads',
        'sr_render_leads_page',
        'dashicons-email-alt2',
        26
    );
}


require_once get_template_directory() . '/includes/class-sr-leads-table.php'; // WP List table style


function sr_render_leads_page() {
    global $wpdb;
    $table = $wpdb->prefix . 'sr_leads';

    if (isset($_GET['mark_contacted'])) {
        $wpdb->update(
            $table,
            ['status' => 'contacted'],
            ['id' => intval($_GET['mark_contacted'])]
        );
        echo '<div class="updated notice"><p>Marked as contacted</p></div>';
    }

    $list_table = new SR_Leads_Table();
    $list_table->prepare_items();

    
	$args = [
        'post_type'      => 'service',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'orderby'        => 'title',
        'order'          => 'ASC',
    ];
	$services = get_posts( $args );
    ?>

    <div class="wrap">
        <h1 class="wp-heading-inline">Leads</h1>

        <form method="get" style="margin: 10px 0; display:flex; gap:10px; flex-wrap:wrap;">
            <input type="hidden" name="page" value="sr-leads" />

            <?php //$list_table->search_box('Search Leads', 'sr-search'); ?>

            <!-- Status Filter -->
            <select name="status">
                <option value="">All Status</option>
                <option value="new" <?php selected($_GET['status'] ?? '', 'new'); ?>>New</option>
                <option value="contacted" <?php selected($_GET['status'] ?? '', 'contacted'); ?>>Contacted</option>
            </select>

            <!-- Service Filter -->
            <select name="service">
                <option value="">All Services</option>
                <?php foreach ($services as $service) : ?>
                    <option value="<?php echo $service->ID; ?>"
                        <?php selected($_GET['service'] ?? '', $service->ID); ?>>
                        <?php echo esc_html($service->post_title); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button class="button">Filter</button>
        </form>

        <?php $list_table->display(); ?>
    </div>
    <?php
}

add_action('admin_head', function () {

    if ( empty($_GET['page']) || $_GET['page'] !== 'sr-leads' ) {
        return;
    }
    ?>
    <style>
        .sr-status {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            text-transform: capitalize;
        }

        .sr-status-new {
            background: #d1fae5;
            color: #065f46;
        }

        .sr-status-contacted {
            background: #dbeafe;
            color: #1e40af;
        }

        .wrap form select,
        .wrap form input[type="search"] {
            height: 32px;
            line-height: 32px;
        }
    </style>
    <?php
});