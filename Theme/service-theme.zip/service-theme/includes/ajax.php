<?php

add_action('wp_ajax_sr_submit_lead_form', 'sr_submit_lead_form');
add_action('wp_ajax_nopriv_sr_submit_lead_form', 'sr_submit_lead_form');

function sr_submit_lead_form() {

    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sr_lead_form_action')) {
        wp_send_json_error(['message' => 'Security check failed']);
    }

    global $wpdb;
    $table = $wpdb->prefix . 'sr_leads';

    $name    = sanitize_text_field($_POST['name'] ?? '');
    $email   = sanitize_email($_POST['email'] ?? '');
    $phone   = sanitize_text_field($_POST['phone'] ?? '');
    $service = intval($_POST['service'] ?? 0);

    $errors = [];

    if (empty($name)) {
        $errors['name'] = 'Name is required';
    }

    if (empty($email) || !is_email($email)) {
        $errors['email'] = 'Valid email is required';
    }

    if (empty($phone)) {
        $errors['phone'] = 'Phone is required';
    }

    if (empty($service)) {
        $errors['service'] = 'Please select a service';
    }

    if (!empty($errors)) {
        wp_send_json_error(['errors' => $errors]);
    }

    $wpdb->insert($table, [
        'name'       => $name,
        'email'      => $email,
        'phone'      => $phone,
        'service_id' => $service,
        'status'     => 'new',
    ]);

    wp_send_json_success(['message' => 'Thanks! We will contact you shortly.']);
}
