<?php
if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class SR_Leads_Table extends WP_List_Table {

    function get_columns() {
        return [
            'name'       => 'Name',
            'email'      => 'Email',
            'phone'      => 'Phone',
            'service'    => 'Service',
            'status'     => 'Status',
            'created_at' => 'Date',
            'action'     => 'Action',
        ];
    }

    function prepare_items() {
        global $wpdb;
        $table = $wpdb->prefix . 'sr_leads';

        $per_page     = 10;
        $current_page = $this->get_pagenum();
        $offset       = ($current_page - 1) * $per_page;

        $status   = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
        $search   = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        $service  = isset($_GET['service']) ? intval($_GET['service']) : 0;

        $where = 'WHERE 1=1';

        if ($status) {
            $where .= $wpdb->prepare(" AND status = %s", $status);
        }

        if ($service) {
            $where .= $wpdb->prepare(" AND service_id = %d", $service);
        }

        if ($search) {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $where .= $wpdb->prepare(
                " AND (name LIKE %s OR email LIKE %s OR phone LIKE %s)",
                $like,
                $like,
                $like
            );
        }

        $total_items = $wpdb->get_var("SELECT COUNT(id) FROM $table $where");

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table $where ORDER BY id DESC LIMIT %d OFFSET %d",
                $per_page,
                $offset
            ),
            ARRAY_A
        );

        $this->items = $results;

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page),
        ]);

        $this->_column_headers = [$this->get_columns(), [], []];
    }


    function column_default($item, $column_name) {

        switch ($column_name) {

            case 'email':
                if (!empty($item['email'])) {
                    return '<a href="mailto:' . esc_attr($item['email']) . '">' . esc_html($item['email']) . '</a>';
                }
                return '—';

            case 'phone':
                if (!empty($item['phone'])) {
                    return '<a href="tel:' . esc_attr($item['phone']) . '">' . esc_html($item['phone']) . '</a>';
                }
                return '—';

            case 'status':
                $status = ucfirst($item['status']);

                if ($item['status'] === 'new') {
                    return '<span class="sr-status sr-status-new">' . $status . '</span>';
                }

                if ($item['status'] === 'contacted') {
                    return '<span class="sr-status sr-status-contacted">' . $status . '</span>';
                }

                return esc_html($status);

            case 'created_at':
                return date('d/m/Y', strtotime($item['created_at']));

            case 'service':
                return $item['service_id'] ? esc_html(get_the_title($item['service_id'])) : '—';

            case 'action':
                if ($item['status'] !== 'contacted') {
                    return '<a class="button button-small" href="?page=sr-leads&mark_contacted=' . intval($item['id']) . '">Mark Contacted</a>';
                }
                return '—';

            default:
                return esc_html($item[$column_name] ?? '');
        }
    }

}
