<?php

function pre( $data = [], $debug = 0 ) {
	echo "<pre>"; print_r($data); echo "</pre>";
	if( $debug == 1 ) {
		die;
	}
}

function get_active_services() {
    $args = [
        'post_type'      => 'service',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'orderby'        => 'title',
        'order'          => 'ASC',
        'meta_query'     => [
            [
                'key'     => 'sr_cpt_status',
                'value'   => 'active',
                'compare' => '='
            ]
        ]
    ];

    $services = get_posts($args);

    $data = [];
    if( !empty( $services ) ) {
        foreach ($services as $service) {
            $inner_data = [
                'service_id' => $service->ID,
                'service_title' => $service->post_title
            ];
            array_push( $data , $inner_data );
        }
    }
    return $data;
}