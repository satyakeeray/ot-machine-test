<?php

if( ! function_exists( 'sr_register_service_cpt' ) ) {
    function sr_register_service_cpt() {

        $labels = array(
            'name'               => __('Services', 'textdomain'),
            'singular_name'      => __('Service', 'textdomain'),
            'menu_name'          => __('Services', 'textdomain'),
            'name_admin_bar'     => __('Service', 'textdomain'),
            'add_new'            => __('Add New', 'textdomain'),
            'add_new_item'       => __('Add New Service', 'textdomain'),
            'new_item'           => __('New Service', 'textdomain'),
            'edit_item'          => __('Edit Service', 'textdomain'),
            'view_item'          => __('View Service', 'textdomain'),
            'all_items'          => __('All Services', 'textdomain'),
            'search_items'       => __('Search Services', 'textdomain'),
            'not_found'          => __('No services found.', 'textdomain'),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'menu_icon'          => 'dashicons-admin-tools',
            'supports'           => array('title', 'editor', 'thumbnail'),
            'has_archive'        => true,
            'rewrite'            => array('slug' => 'sr-service'),
            'show_in_rest'       => true,
        );

        register_post_type('service', $args);

    }
}


add_action('init', 'sr_register_service_cpt');
