<?php
// Enqueue main style, custom CSS, and custom JS
function service_theme_enqueue() {
    
	// Main theme style.css
    wp_enqueue_style( 'service-theme-style', get_stylesheet_uri(), array(), '1.0' );

	// Bootstrap css
	wp_enqueue_style( 'bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css', array(), '5.3.2' );
    
    // Custom CSS
    wp_enqueue_style( 'service-theme-custom', get_template_directory_uri() . '/assets/css/custom.css', array(), '1.0' );
    

	// Bootstrap 5.3.2 JS Bundle (includes Popper.js) - loads in footer
    wp_enqueue_script( 'bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', array(), '5.3.2', true );


    // Custom JS (create /js/custom.js) - loads in footer
    wp_enqueue_script( 'service-theme-custom', get_template_directory_uri() . '/assets/js/custom.js', array('jquery'), '1.0', true );

	wp_localize_script('service-theme-custom', 'srLeadForm', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('sr_lead_form_action'),
    ]);
}
add_action( 'wp_enqueue_scripts', 'service_theme_enqueue' );