<?php

add_shortcode('sr_lead_form', 'sr_render_contact_form');

if( ! function_exists( 'sr_render_contact_form' ) ) {
    function sr_render_contact_form() {
        ob_start();
        $uid = 'sr-lead-' . wp_generate_uuid4();
        ?>
        <form class="row g-3 justify-content-center sr-lead-form" id="<?php echo esc_attr($uid); ?>" data-form-id="<?php echo esc_attr($uid); ?>">
            <?php wp_nonce_field('sr_lead_form_action', 'sr_lead_nonce'); ?>
            <div class="col-md-5">
                <input type="text" class="form-control name" placeholder="Your Name" id="name" />
                <span id="name-error" class="error name-error"></span>
            </div>
            <div class="col-md-5">
                <input type="email" class="form-control email" placeholder="Your Email" id="email" />
                <span id="email-error" class="error email-error"></span>
            </div>
            <div class="col-md-5">
                <input type="number" class="form-control phone" placeholder="Phone" id="phone"/>
                <span id="phone-error" class="error phone-error"></span>
            </div>
            <div class="col-md-5">
                <select class="form-select service" id="service">
                    <option value="">Select Service</option>
                    <?php 
                        $active_services = get_active_services();
                        if( !empty( $active_services ) ) {
                            foreach( $active_services as $service ) {
                                ?><option value="<?php echo $service['service_id']; ?>"><?php echo $service['service_title']; ?></option><?php
                            }
                        }
                    ?>
                </select>
                <span id="service-error" class="error service-error"></span>
            </div>
            <div class="col-md-10 text-center">
                <button class="btn btn-primary btn-lg submit-btn">Submit</button>
            </div>
        </form>
        <div class="response-message" id="response-message-<?php echo esc_attr($uid); ?>" data-form-id="<?php echo esc_attr($uid); ?>"></div>
        <?php
        return ob_get_clean();
    }
}


