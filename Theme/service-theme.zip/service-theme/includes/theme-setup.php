<?php
// Theme support
function service_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    register_nav_menus( array( 'primary' => 'Primary Menu' ) );
}
add_action( 'after_setup_theme', 'service_theme_setup' );


//add_action('after_switch_theme', 'sr_create_leads_table');


add_action('after_switch_theme', 'sr_check_acf_on_theme_activation');

function sr_check_acf_on_theme_activation() {

    if ( ! class_exists('ACF') ) {

        // Switch back to default theme
        switch_theme( WP_DEFAULT_THEME );

        // Show error message
        add_action('admin_notices', function () {
            ?>
            <div class="notice notice-error">
                <p>
                    ❌ <strong>Theme activation failed.</strong><br>
                    This theme requires <strong>Advanced Custom Fields Pro</strong> to be installed and activated.
                </p>
            </div>
            <?php
        });
    }
    sr_create_leads_table();
}

function sr_create_leads_table() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'sr_leads';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        name VARCHAR(150) NOT NULL,
        email VARCHAR(150) NOT NULL,
        phone VARCHAR(50) DEFAULT '',
        service_id BIGINT(20) UNSIGNED DEFAULT 0,
        status VARCHAR(20) DEFAULT 'new',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}
