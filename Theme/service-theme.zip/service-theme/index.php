<?php get_header(); ?>

<div class="sr-page-wrapper">
    <?php if ( have_posts() ) : ?>
        <?php 
        while ( have_posts() ) : the_post(); 
            the_content();
        endwhile; 
        ?>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
