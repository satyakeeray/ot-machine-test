<?php get_header(); ?>

<div class="sr-page-wrapper">
    <div class="container py-5">

        <?php if ( have_posts() ) : ?>
            <?php while ( have_posts() ) : the_post(); ?>

                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                    <header class="mb-4">
                        <h1 class="mb-2"><?php the_title(); ?></h1>
                        <p class="text-muted small">
                            Published on <?php echo get_the_date(); ?>
                        </p>
                    </header>

                    <div class="sr-single-content">
                        <?php the_content(); ?>
                    </div>

                </article>

            <?php endwhile; ?>
        <?php else : ?>
            <p>No content found.</p>
        <?php endif; ?>

    </div>
</div>

<?php get_footer(); ?>
